﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Autor
    {
        private string nombre;
        private string apellido;

        public Autor(string nombre, string apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }

        public static implicit operator string(Autor p)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("NOMBRE: " + p.nombre + "\n");
            sb.AppendLine("APELLIDO: " + p.apellido + "\n");

            return sb.ToString();
        }
        public static bool operator ==(Autor a, Autor b)
        {
            return (a.nombre==b.nombre&&a.apellido==b.apellido);
        }

        public static bool operator !=(Autor a, Autor b)
        {
            return !(a == b);
        }
    }
}
