﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Biblioteca
    {
        private int capacidad;
        private List<Libro> _libros;

        /*public double PrecioDe { get; set; }
        public double PrecioDe { get; set; }
        public double PrecioDe { get; set; }*/

        private Biblioteca()
        {
            this._libros = new List<Libro>();
        }
        private Biblioteca(int capacidad)
        {
            this.capacidad = capacidad;
        }
    }
}
