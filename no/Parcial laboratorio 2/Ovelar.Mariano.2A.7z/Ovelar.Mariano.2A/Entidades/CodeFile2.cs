﻿public enum EGenero
{
    Accion, Romantica, CienciFiccion
}