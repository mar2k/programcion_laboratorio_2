﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Novela : Libro
    {
        EGenero genero;
        public Novela(string titulo, float precio,Autor autor,EGenero genero
            : base(titulo,autor,precio) 
        {
            this.genero=genero;
        }

        public static implicit operator double(Novela n)
        {
            return n._precio;
        }
        public string Mostrar()
        {
            return (string)this + "GENERO:" +this.genero.ToString()+"\n";
        }

        public static bool operator ==(Novela a, Novela b)
        {
            return (a.genero == b.genero && (Libro) a == b);
        }

        public static bool operator !=(Novela a, Novela b)
        {
            return !(a == b);
        }
    }
}
