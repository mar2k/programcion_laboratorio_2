﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veiculo_Lavadero
{
    public class Auto : Vehiculo
    {
        protected int _cantidadAsientos; 

        public Auto(string patente, Byte cantRuedas, EMarcas marca) : base(patente,cantRuedas,marca)
        {
            this._cantidadAsientos = 5;
        }
        public Auto(string patente,EMarcas marca ,int cantAsientos) : this(patente, 4, marca)
        {
            this._cantidadAsientos = cantAsientos;
        }


        protected override string Mostrar()
        {
            return base.ToString() + "Cantidad de Asientos: "+ this._cantidadAsientos +"\n";
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
