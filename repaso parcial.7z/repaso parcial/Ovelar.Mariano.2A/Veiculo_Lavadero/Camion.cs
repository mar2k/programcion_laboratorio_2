﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veiculo_Lavadero
{
    public class Camion : Vehiculo
    {
        protected float _tara;
        public Camion(string patente, Byte cantRuedas, EMarcas marca) : base(patente, cantRuedas, marca)
        {

        }
        public Camion(Vehiculo vehiculo, float tara) : this(vehiculo.Patente, vehiculo.Ruedas, vehiculo.Marca)
        {
            this._tara = tara;
        }

        protected override string Mostrar()
        {
            return base.ToString() + "Tara: " + this._tara + "\n";
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
