using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veiculo_Lavadero
{
    class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        public Lavadero(string razonSocial):this()
        {
            this._razonSocial = razonSocial;
        }
        private Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        static Lavadero()
        {
            Random generador = new Random();

            Lavadero._precioAuto = generador.Next(149, 564);
            Lavadero._precioCamion = generador.Next(149, 564);
            Lavadero._precioMoto = generador.Next(149, 564);
        }

        public string LavaderoToString
        {
            get
            {
                return ""+ this._razonSocial.ToString() +"Precios\n"+"Auto: "+Lavadero._precioAuto.ToString() + "Camion: "+ Lavadero._precioCamion.ToString() + "Moto: " + Lavadero._precioMoto.ToString(),this.;
            }
        }

        public string Vehiculos
        {
            get
            {
                string retorno= "Lista de Vehiculos\n";
                foreach(Vehiculo vehiculo in this._vehiculos)
                {
                    retorno += vehiculo.ToString()+"\n";
                }
                return retorno;
            }
        }


        /*
            Todos los atributos se inicializaran desde su constructor con parámetros. El constructor por
            default, que será privado, será el único encargado de inicializar la lista genérica.
            El constructor estático inicializara, mediante un valor aleatorio cada uno de los precios. El rango irá
            desde los $150 a los $565. (No deben repetirse)
        */


    }
}
