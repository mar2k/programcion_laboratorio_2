﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veiculo_Lavadero
{
    public class Moto : Vehiculo
    {
        protected float _cilindrada;

        public Moto(string patente, Byte cantRuedas, EMarcas marca) : base(patente, cantRuedas, marca)
        {

        }
        public Moto(EMarcas marca,float cilindrada,string patente,byte cantRuedas) : this(patente, cantRuedas, marca)
        {
            this._cilindrada = cilindrada;
        }

        protected override string Mostrar()
        {
            return base.ToString() + "Cilindrada: " + this._cilindrada + "\n";
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
    }
}
