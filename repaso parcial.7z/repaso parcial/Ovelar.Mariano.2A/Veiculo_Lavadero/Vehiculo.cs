﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veiculo_Lavadero
{
    public abstract class Vehiculo
    {
        
        protected string _patente;
        protected byte _cantRuedas;
        protected EMarcas _marca;

        public string Patente { get { return this._patente; } }
        public byte Ruedas { get { return this._cantRuedas; } set { this._cantRuedas = value; } }
        public EMarcas Marca { get { return this._marca; } }


        protected virtual string Mostrar()
        {
            string retorno="";

            retorno += "Patente: " + this._patente + "\n";
            retorno += "Auto: " + this._cantRuedas.ToString() + "\n";
            retorno += "Marca: " + this._marca.ToString() + "\n";

            return retorno;
        }
        public Vehiculo(string patente,Byte cantRuedas,EMarcas marca)
        {
            this._patente = patente;
            this._cantRuedas = cantRuedas;
            this._marca = marca;
        }
        public override string ToString()
        {
            return this.Mostrar();
        }
        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            return (v1._patente == v2._patente);
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1==v2);
        }
    }
}
